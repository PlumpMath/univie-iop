<?php
  class Nina {
    function getWeather($type,$ort) {
      $stations = new StdClass;
      $station1 = new StdClass;
      $station2 = new StdClass;
 
      $station1->anlage = 'Hohe Warte';
      $station1->temperatur= '12 Grad';
 
      $station2->anlage = 'Pfaender';
      $station2->temperatur= '50 Grad';
 
      $stations->station = array($station1,$station2);
 
      return $stations;
    }
  }
 
  if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $test = new Nina;
    header('content-type: text/plain');
    print_r($test->getWeather('a','b'));
  }
 
  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    ini_set("soap.wsdl_cache_enabled","0");
    $server = new SoapServer('blubb.wsdl');
    $server->setClass('Nina');
    $server->handle();
    exit;
  }
?>