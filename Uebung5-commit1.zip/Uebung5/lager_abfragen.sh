#!/bin/bash

curl -v http://localhost/uebung5/lagerverwaltung.php/$1/$2